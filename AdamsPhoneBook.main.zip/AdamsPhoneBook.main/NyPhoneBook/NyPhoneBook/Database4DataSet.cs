﻿namespace NyPhoneBook
{


    partial class Database4DataSet
    {
    }
}
