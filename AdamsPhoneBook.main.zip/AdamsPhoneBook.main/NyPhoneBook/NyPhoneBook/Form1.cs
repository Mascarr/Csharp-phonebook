﻿using System;
using System.Data.OleDb;
using System.Windows.Forms;

namespace NyPhoneBook
{
    public partial class Form1 : Form
    {
        private readonly string connectionString = "Provider = Microsoft.ace.oledb.12.0; Data Source = Database4.accdb";

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (OleDbConnection conn = new OleDbConnection(connectionString))
            {
                conn.Open();

                using (OleDbCommand comm = new OleDbCommand())
                {
                    comm.CommandText = "INSERT INTO Tabell1 ([Fname], [Lname], [Email], [Number]) VALUES (@Fname, @Lname, @Email, @Number)";
                    comm.Connection = conn;
                    comm.Parameters.AddWithValue("@Fname", textBox1.Text);
                    comm.Parameters.AddWithValue("@Lname", textBox2.Text);
                    comm.Parameters.AddWithValue("@Email", textBox3.Text);
                    comm.Parameters.AddWithValue("@Number", textBox4.Text);
                    comm.ExecuteNonQuery();
                }

                MessageBox.Show("Data successfully saved");

                // Uppdatera DataGridView för att visa den uppdaterade datan
                this.tabell1TableAdapter.Fill(this.database4DataSet.Tabell1);

                // Rensa inmatningsfälten
                textBox1.Text = string.Empty;
                textBox2.Text = string.Empty;
                textBox3.Text = string.Empty;
                textBox4.Text = string.Empty;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.tabell1TableAdapter.Fill(this.database4DataSet.Tabell1);

            // Rensa DataGridView
            dataGridView1.DataSource = null;
        }

        // Används
        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            // Används
        }

        // Används
        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            // Används
        }

        // Används
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            // Används
        }

        // Används
        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            // Används
        }

        // Används
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // Används
        }

        private void button2_Click(object sender, EventArgs e)
        {
            using (OleDbConnection conn = new OleDbConnection(connectionString))
            {
                conn.Open();

                using (OleDbCommand comm = new OleDbCommand())
                {
                    comm.CommandText = "DELETE FROM Tabell1 WHERE Fname = @Fname AND Lname = @Lname";
                    comm.Connection = conn;
                    comm.Parameters.AddWithValue("@Fname", textBox1.Text);
                    comm.Parameters.AddWithValue("@Lname", textBox2.Text);
                    comm.ExecuteNonQuery();
                }

                MessageBox.Show("Data successfully removed");

                // Rensa inmatningsfälten
                textBox1.Text = string.Empty;
                textBox2.Text = string.Empty;
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            // Visa instruktioner för att lägga till information
            string addInstructions = "Du kan lägga till information genom att fylla i ditt förnamn, efternamn, e-post och telefonnummer.";
            MessageBox.Show(addInstructions, "Instruktioner", MessageBoxButtons.OK, MessageBoxIcon.Information);

            // Visa instruktioner för att radera
            string deleteInstructions = "För att radera behöver du ange ditt förnamn och efternamn. Detta kommer att radera alla med liknande förnamn.";
            MessageBox.Show(deleteInstructions, "Instruktioner", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
